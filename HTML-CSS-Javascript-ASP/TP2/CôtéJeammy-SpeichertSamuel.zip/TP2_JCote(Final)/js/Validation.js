﻿function ClientValidate(source, arguments) {
    arguments.IsValid = arguments.value.lenght == 7;
}