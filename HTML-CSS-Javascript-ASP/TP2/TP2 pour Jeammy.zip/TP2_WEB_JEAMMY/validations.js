﻿function ClientValidate(source, arguments)
{
    arguments.IsValid = TextBoxMatricule.Text.Length = 7;  
}