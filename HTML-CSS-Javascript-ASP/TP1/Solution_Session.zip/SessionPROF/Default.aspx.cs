﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{

    /************
    *DANIELH: Mon exercice comporte un vice caché sur la manipulation du id, pouvez-vous le trouver ?
    ************/
    private int currentId = 0;
    private List<ItemMemoire> listMemory = new List<ItemMemoire>();

    protected void Page_Init(object sender, EventArgs e)
    {
        //Il faut faire ce code seulement à l'initalisation sans quoi on écrasera notre variable de session
        if (!IsPostBack)
        {
            //On stocke la liste en partant dans la session ce qui est primordial lors de la première récupération
            //On aurait donc pu omettre la propriété et créer une liste ici, car dorénavant on ne travaillera que sur la session
            Session["liste"] = listMemory;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!String.IsNullOrEmpty(TextBox1.Text))
        {
            //Création du ListItem
            ListItem item = new ListItem();
            item.Value = currentId.ToString();
            item.Text = TextBox1.Text;
            //On ajoute l'item dans la première liste de l'interface
            ListBox1.Items.Add(item);

            //On doit absolument récuperer la liste de la session car elle est à jour !!
            List<ItemMemoire> liste = (List<ItemMemoire>)Session["liste"];

            //On crée notre item en mémoire
            ItemMemoire itemMemoire = new ItemMemoire(currentId.ToString(), TextBox1.Text);

            //on travaille sur la liste récupérée !
            liste.Add(itemMemoire);

            //important sans quoi tout le monde aura le même id, mais voir mon commentaire dans les propriétés !
            currentId++;

            //on restocke la liste manipulée dans la mémoire
            Session["liste"] = liste;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Récupération de la liste dans la session, très important
        List<ItemMemoire> liste = (List<ItemMemoire>)Session["liste"];

        //On vide la liste sinon elle va dupliquer les informations
        ListBox2.Items.Clear();

        //Pour chaque item trouvé dans la liste mémoire on crée un ListItem et on l'ajoute dans le 2e ListBox
        foreach (ItemMemoire item in liste)
        {
            ListItem listItem = new ListItem();
            listItem.Value = item.GetValue();
            listItem.Text = item.GetText();
            ListBox2.Items.Add(listItem);
        }

        //Pas besoin de restocker la liste elle n'a pas été changée, seulement lue !
    }


    /************
    *DANIELH: Attention au Remove, sélectionner 1 item à la fois et faire le nettoyage dans la liste mémoire, ne pas oublier de manipuler la session en tout temps !
    ************/
}