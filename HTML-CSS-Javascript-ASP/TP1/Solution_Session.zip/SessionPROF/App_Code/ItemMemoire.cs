﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de Liste
/// </summary>
public class ItemMemoire
{
    private string value = "";
    private string text = "";
            
    public ItemMemoire(string value, string text)
    {
        this.value = value;
        this.text = text;
    }

    public string GetValue()
    {
        return this.value;
    }

    public string GetText()
    {
        return this.text;
    }

}