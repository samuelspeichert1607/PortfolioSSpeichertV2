#pragma once

#include <SFML/Graphics.hpp>
#include "Player.h"
#include "LevelManager.h"

#include "Block.h"
#include "Goomba.h"
#include "CleverGoomba.h"
#include "ParaGoomba.h"
using namespace sf;



namespace platformer
{
	class Game
	{
	public:
		Game();
		~Game();
		int run();

		const int LARGEUR = 800;
		const int HAUTEUR = 480;
		const float VITESSE = 5;
		const float GRAVITE = 2;

		//Nombre d'animations et frames par animation qu'on a dans notre spriteSheet.
		//Oui c'est hardcod�; on ne peut pas faire autrement
		//Si vous avez une solution venez me l'exposer
		const int NOMBRE_ANIMATIONS = 3;
		const int NOMBRE_FRAMES = 2;

	private:
		bool init();
		void getInputs();
		void update();
		void draw();

		//Nouveau � pr�sent qu'on utilise les pointeurs, on va tout lib�rer avant de terminer
		void unload();
		bool testCollisionBoxes(int x, int y, int oWidth, int oHeight, int xTwo, int yTwo, int oTwoWidth, int oTwoHeight);
		bool testCollisionBoxes2(Sprite spr1, Sprite spr2);
		void BlockBuilder(const char levelPath[], const char blockTPath[]);
		bool VerifierCollisionBox();
		const int numBackground = 3;

		Sprite* background;
		Texture* backgroundT;
		Sprite* backgroundSky;
		Texture* backgroundSkyT;

		Player* player = NULL;

		bool can_jump = false;

		//liste des blocks du niveau.


		vector<Block> blockList;
		vector<Ennemy> ennemyList;

		RenderWindow mainWin;
		View view;
		Event event;
	};
}