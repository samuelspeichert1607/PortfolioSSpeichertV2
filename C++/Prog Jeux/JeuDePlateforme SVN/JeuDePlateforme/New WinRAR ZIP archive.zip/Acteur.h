#pragma once
#include <SFML/Graphics.hpp>
#include <string>

using namespace sf;

using std::string;

namespace platformer
{
	class Acteur : public Sprite
	{
		public:
			Acteur(const float posX, const float posY, RenderWindow* const renderWindow);
			~Acteur();

			bool chargerTextures(const char texturePath[]);
			void ajustementsVisuels();
			
			Texture texture; // static Texture texture;

		protected:

			const enum DIRECTIONS { IMMOBILE = -1, GAUCHE, DROITE, SAUT };
			const float VITESSE = 9.0f;
			const int SPEED_ANIMATION = 10;

			RenderWindow* renderWindow;

			IntRect** intRects;
			int animateur;
			int cadran;

			Vector2f interfaceDeplacement;

			int animateurImmobile;
			int directionImmobile;
			bool estMobile;
	};
}

