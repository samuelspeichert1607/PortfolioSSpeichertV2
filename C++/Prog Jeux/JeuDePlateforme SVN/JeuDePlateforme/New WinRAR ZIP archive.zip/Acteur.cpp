#include "Acteur.h"

using namespace platformer;
//Texture Acteur::texture;



Acteur::Acteur(const float posX, const float posY, RenderWindow* const renderWindow) : renderWindow(renderWindow), cadran(6), animateur(0), animateurImmobile(0), directionImmobile(1), estMobile(false)
{
	setPosition(posX, posY);
}

Acteur::~Acteur()
{

}

bool Acteur::chargerTextures(const char texturePath[])
{
	if (!texture.loadFromFile(texturePath))
	{
		return false;
	}

	texture.setSmooth(false);
	return true;
}

void Acteur::ajustementsVisuels()
{
	setTexture(texture);
	//Pour l'animation
	/*intRectsImmobile = new IntRect[NBR_ANIMS_IMMOBILE];
	intRectsMouvement = new IntRect[NBR_ANIMS_MOUVEMENT];
	intRectsJump = new IntRect[NBR_ANIMS_JUMP];
	intRectsMort = new IntRect[NBR_ANIMS_MORT];
	intRectsVictoire = new IntRect[NBR_ANIMS_VICTOIRE];

	int hauteur = texture.getSize().y / NBR_NIVEAUX;

	for (size_t i = 0; i < NBR_ANIMS_IMMOBILE; i++)
	{
		int largeur = texture.getSize().x / NBR_ANIMS_IMMOBILE;
		intRectsImmobile[i].left = largeur * i;
		intRectsImmobile[i].top = hauteur * i;
		intRectsImmobile[i].width = largeur;
		intRectsImmobile[i].height = hauteur;
	}

	for (size_t i = 0; i < NBR_ANIMS_MOUVEMENT; i++)
	{
		int largeur = texture.getSize().x / NBR_ANIMS_MOUVEMENT;
		intRectsMouvement[i].left = largeur * i;
		intRectsMouvement[i].top = hauteur * i;
		intRectsMouvement[i].width = largeur;
		intRectsMouvement[i].height = hauteur;
	}

	for (size_t i = 0; i < NBR_ANIMS_JUMP; i++)
	{
		int largeur = texture.getSize().x / NBR_ANIMS_JUMP;
		intRectsJump[i].left = largeur * i;
		intRectsJump[i].top = hauteur * i;
		intRectsJump[i].width = largeur;
		intRectsJump[i].height = hauteur;
	}

	for (size_t i = 0; i < NBR_ANIMS_MORT; i++)
	{
		int largeur = texture.getSize().x / NBR_ANIMS_MORT;
		intRectsMort[i].left = largeur * i;
		intRectsMort[i].top = hauteur * i;
		intRectsMort[i].width = largeur;
		intRectsMort[i].height = hauteur;
	}

	for (size_t i = 0; i < NBR_ANIMS_VICTOIRE; i++)
	{
		int largeur = texture.getSize().x / NBR_ANIMS_VICTOIRE;
		intRectsVictoire[i].left = largeur * i;
		intRectsVictoire[i].top = hauteur * i;
		intRectsVictoire[i].width = largeur;
		intRectsVictoire[i].height = hauteur;
	}


	setTextureRect(intRectsImmobile[cadran]);
	setOrigin(intRectsImmobile[0].height / 2, intRectsImmobile[0].width / 2);*/
}

