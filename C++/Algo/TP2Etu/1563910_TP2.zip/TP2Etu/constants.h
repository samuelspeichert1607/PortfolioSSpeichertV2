#pragma once

const int CUBE_SIZE = 5;