#include "ConsoleMenu.h"

int main()
{
	ConsoleMenu console;
	console.Run();

	return 0;
}