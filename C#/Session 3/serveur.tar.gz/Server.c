#include<stdio.h>
#include<string.h>    //strlen
#include<stdlib.h>
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write 
#include<pthread.h>
#include <ifaddrs.h>
#include <sys/types.h>
#include <time.h>

void *connection_handler(void *);

char* concat(const char *s1, const char *s2)
{
    char *result = malloc(strlen(s1)+strlen(s2)+2);//+1 for the zero-terminator
    //in real code you would check for errors in malloc here
    /*for (int i = strlen(result); i >= 0; i--)
    {
	result[i] = '\0';
    }*/
    strcpy(result, s1);
    strcat(result, s2);
    //puts(result);
    return result;
}
struct user
{
	char* username;
	char* password;
	pthread_t thread;
	int socket;
	int isDeconected;
	int nbPoints;
	int noSentCard;
	int isJuge;
};
struct user users[8];
int numberOfUsers = 0;
int currentQuestionCard = 0;
int usedRespondCard[100];
int nbRespondCardSent = 0;
int usedQuestionCard[100];
int nbQuestionCardSent = 0;
pthread_mutex_t lock;
void SaveRequest(char* fileName, char* message, char* noClient)
{
	FILE* streamInput = fopen(fileName, "a+");//tentative d'ouverture du fichier
	puts(":)");
	//vérification du résultat
	if (streamInput == NULL)
	{
		puts("error opening file!");
	}

	time_t t = time(NULL);
	struct tm *tm = localtime(&t);
	char s[64];
	strftime(s, sizeof(s), "%c", tm);
	//puts("hello");
	char *text = concat(s, ":client #"); 
	text = concat(text, noClient);
	text = concat(text, ":request:");
	text = concat(text, message);
	fprintf(streamInput, "%s", text);
	fclose(streamInput);
}

int main(int argc , char *argv[])
{
    int socket_desc , new_socket , c, *new_sock;
    struct sockaddr_in server , client;
    char *message;
    struct ifaddrs * ifAddrStruct=NULL;
    struct ifaddrs * ifa=NULL;
    void * tmpAddrPtr=NULL;

    getifaddrs(&ifAddrStruct);//obtenir adresse Ip

    for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next)//afficher adresse ip
    {
        if (!ifa->ifa_addr) {
            continue;
        }
        if (ifa->ifa_addr->sa_family == AF_INET) { // check it is IP4
            // is a valid IP4 Address
            tmpAddrPtr=&((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
            char addressBuffer[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
            printf("%s IP Address %s\n", ifa->ifa_name, addressBuffer); 
        } else if (ifa->ifa_addr->sa_family == AF_INET6) { // check it is IP6
            // is a valid IP6 Address
            tmpAddrPtr=&((struct sockaddr_in6 *)ifa->ifa_addr)->sin6_addr;
            char addressBuffer[INET6_ADDRSTRLEN];
            inet_ntop(AF_INET6, tmpAddrPtr, addressBuffer, INET6_ADDRSTRLEN);
            printf("%s IP Address %s\n", ifa->ifa_name, addressBuffer); 
        } 
    }
    if (ifAddrStruct!=NULL)//liberer la memoire
    {
	freeifaddrs(ifAddrStruct);
    }

    int port, userInput, isInputOk = 0;
    while (isInputOk == 0)
    {
	printf("Enter a port: ");
	userInput = scanf("%d", &port);
	if (userInput == EOF)
	{
	    puts("retry");
	}
	else if (userInput == 0)
	{
	    puts("you need to enter something!");
	}
	else
	{
	    printf("Got %d\n", port);
	    isInputOk = 1;
	}
    }
    

    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( port );
     
    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        puts("bind failed");
        return 1;
    }
    puts("bind done");
     
    //Listen
    listen(socket_desc , 3);

    if (pthread_mutex_init(&lock, NULL))//initialiser le mutex
    {
        printf("\n mutex init failed\n");
        return 1;
    }

    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);
    while( (new_socket = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) )
    {
        puts("Connection accepted\nentrer: 1(username),(password) pour vous identifier");

        pthread_t sniffer_thread;
        new_sock = malloc(1);
        *new_sock = new_socket;
	users[numberOfUsers].thread = sniffer_thread;
	users[numberOfUsers].socket = new_socket;
        if( pthread_create( &sniffer_thread , NULL ,  connection_handler , (void*) new_sock) < 0)
        {
            perror("could not create thread");
            return 1;
        }
         
        //Now join the thread , so that we dont terminate before the thread
        //pthread_join( sniffer_thread , NULL);
        puts("Handler assigned");
    }

    if (new_socket<0)
    {
        perror("accept failed");
        return 1;
    }
    pthread_mutex_destroy(&lock);//detruire mutex   
    return 0;
}

 /*
 * This will handle connection for each client
 * */
void *connection_handler(void *socket_desc)
{
    int userNumber = numberOfUsers;
    numberOfUsers++;
    char userNumberString[15];
    sprintf(userNumberString, "%d", userNumber);
    puts("hello");
    //Get the socket descriptor
    int sock = *(int*)socket_desc;
    int read_size;
    char *message , client_message[2000];
    users[userNumber].isDeconected = 1;
    users[userNumber].nbPoints = 0;
    int nbWrongRequets = 0;
    int noWrongStory = rand() % 8;
    //Receive a message from client
    while( (read_size = recv(users[userNumber].socket , client_message , 2000 , 0)) > 0  )
    {
	pthread_mutex_lock(&lock);//barrer le mutex pour se reserver les variables
	SaveRequest("log",client_message, userNumberString);
	puts(client_message);
	message = "\0";
        //Send the message back to client
	if (client_message[0] == '3')
	{
	    message = concat(message, "4vous avez ete deconnecte.");
	    message = concat(message, "\n\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\0");
	    write(users[userNumber].socket, message , strlen(message));
	    puts("Client disconnected");
	    fflush(stdout);
	    break;
	}
	else if (client_message[0] == '1' && users[userNumber].isDeconected == 1)
	{
	    puts("connection");
	    users[userNumber].isDeconected = 0;
	    char username[2000];
	    char password[2000];
	    int j = 0;
	    int isUsernamePassed = 0;
	    for (int i = 1; i < strlen(client_message); i++)
	    {
		if (client_message[i] == ',')
		{
		    isUsernamePassed++;
		    j = -1;
		}
		else if (isUsernamePassed == 0)
		{
		    username[j] = client_message[i];
		}
		else if (isUsernamePassed == 1)
		{
		    password[j] = client_message[i];
		}
	        j++;
	    }
	    users[userNumber].username = username;
	    users[userNumber].password = password;
	    puts(username);
	    puts(password);
	    message = concat(message, "2");
	    message = concat("2", users[userNumber].username);
	    message = concat(message,",");
	    message = concat(message, users[userNumber].password);
	    puts("test");
	}
	else if (client_message[0] == '5')
	{
	    message = concat(message, "6");
	    for (int i = 0; i < numberOfUsers; i++)
	    {
		if (users[i].isDeconected == 0)
		{
		     message = concat(message, users[i].username);
		     if (i != numberOfUsers)
		     {
			message = concat(message, ",");
		     }
		}
	    }
	}
	else if (client_message[0] == '7')
	{
	    message = concat(message, "8");
	    char username[2000];
	    int j = 0;
	    for (int i = 1; i < strlen(client_message); i++)
	    {
		if (client_message[i] == '.')
		{
		    break;
		}
		else
		{
		    username[j] = client_message[i];
		}
	        j++;
	    }
	    puts(username);
	    for (int i = 0; i < numberOfUsers; i++)
	    {
		if (strcmp(users[i].username,username) == 0)
		{
		     char str[15];
		     sprintf(str, "%d", users[i].nbPoints);
		     puts("ok");
		     message = concat(message, str);
		     break;
		}
	    }
	}
	else if (client_message[0] == '9')
	{
	    message = concat(message, "10:");
	    int noCard = 0;
	    int isNoCardOk = 0;
	    while (isNoCardOk < nbRespondCardSent)
	    {
		noCard = rand() % 100;
		isNoCardOk = 0;
		for (int i = 0; i < nbRespondCardSent; i++)
		{
		   if (usedRespondCard[i] != noCard)
		   {
			isNoCardOk++;
		   }
		}
	    }
	    nbRespondCardSent++;
	    usedRespondCard[nbRespondCardSent] = noCard;
	    char str[15];
	    sprintf(str, "%d", noCard);
	    message = concat(message, str);
	}
	else if (client_message[0] == '1')
	{
	    puts(message);
	    if (client_message[1] == '1')
	    {
		message = concat(message, "12:");
		int noCard = 0;
		int isNoCardOk = 0;
		while (isNoCardOk < nbQuestionCardSent)
		{
		     noCard = rand() % 100;
		     isNoCardOk = 0;
		     for (int i = 0; i < nbQuestionCardSent; i++)
		     {
			if (usedQuestionCard[i] != noCard)
			{
			     isNoCardOk++;
			}
		     }
		}
		nbQuestionCardSent++;
		usedQuestionCard[nbQuestionCardSent] = noCard;
		char str[15];
		sprintf(str, "%d", noCard);
		message = concat(message, str);
		message = concat(message, ",");
		int noJuge = 0;
		do
		{
		     noJuge = rand() % numberOfUsers;
		}while (users[noJuge].isDeconected == 1);
		message = concat(message, users[noJuge].username);
		for (int i = 0; i < numberOfUsers; i++)
		{
		    if (i != userNumber)
		    {
			write(users[i].socket, message , strlen(message));
		    }
	        }
	    }
	    else if (client_message[1] == '3')
	    {
		message = concat(message, "14:");
		char noCard[4];
		int j = 0;
		for (int i = 3; i < strlen(client_message); i++)
		{
		    if (client_message[i] == '.')
		    {
			break;
		    }
		    else
		    {
			noCard[j] = client_message[i];
			j++;
		    }
		}
		puts(noCard);
		users[userNumber].noSentCard = strtol(noCard, NULL, 10);
		message = concat(message, noCard);
		for (int i = 0; i < numberOfUsers; i++)
		{
		    if (i != userNumber)
		    {
			write(users[i].socket, message , strlen(message));
		    }
	        }
	    }
	    else if (client_message[1] == '5')
	    {
		message = concat(message, "16:");
		char noCard[4];
		int j = 0;
		for (int i = 3; i < strlen(client_message); i++)
		{
		    if (client_message[i] == '.')
		    {
			break;
		    }
		    else
		    {
			noCard[j] = client_message[i];
			j++;
		    }
		}
		puts(noCard);
		int card = strtol(noCard, NULL, 10);
		message = concat(message, noCard);
		message = concat(message, ",");
		for (int i = 0; i < numberOfUsers; i++)
		{
		    if (users[i].isDeconected == 0 && users[i].noSentCard == card)
		    {
			users[i].nbPoints++;
			message = concat(message, users[i].username);
		    }
		    users[i].noSentCard = 0;
		    users[i].isJuge = 0;
		}
		for (int i = 0; i < numberOfUsers; i++)
		{
		    if (i != userNumber)
		    {
			write(users[i].socket, message , strlen(message));
		    }
	        }
	    }
	    else if (client_message[1] == '7')
	    {
		message = concat(message, "18");
		message = concat(message, users[userNumber].username);
		message = concat(message, " : ");
		char comment[2000];
		int j = 0;
		for (int i = 2; i < strlen(client_message); i++)
		{
		     if (client_message[i] == '.')
		     {
			break;
		     }
		     else
		     {
			comment[j] = client_message[i];
			j++;
		     }
		}
		message = concat(message, comment);
		for (int i = 0; i < numberOfUsers; i++)
		{
		    if (i != userNumber)
		    {
			write(users[i].socket, message , strlen(message));
		    }
		}
	    }
	}
	else 
	{
	    //https://www.youtube.com/watch?v=f0eHors2npc
	    if (noWrongStory == 0)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, "Wait!\nWhat was that?\n\nTIS I!\nNever fear: Linux is here!\nTo destroy eveil monters and all you hold dear!\nI will end your cruel necromancing!\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "To hell demon client, from whence you came.\nYou're in Castlevania, this isn't a game.\nNow run away, free this server of it's chains.\nAs God is my witness, I shall see you all slain!\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, "OH God NO!\n\nTIS I!\nNever fear, Linux is here!\n(Shit!)\nThe power of Christ is infused in my requests!\nI'll put an end to your horrible reign!\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "I RIP OUT YOUR CONNECTION!\n(Agh!)\nI will restore the glory of light.\nWith my sokets and the threads, I'll take back the night!\n");
		}
		else if (nbWrongRequets == 4)
		{
		     message = concat(message, "Sound the death knell!\n");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, " you she-bitch, I will see you in hell!\n");
		}
		else if (nbWrongRequets == 5)
		{
		     message = concat(message, "You don't invite me to your parties.\nDo you know how that feels?\n");
		}
		else if (nbWrongRequets == 6)
		{
		     message = concat(message, "No!... Yes.\n");
		}
		else if (nbWrongRequets == 7)
		{
		     message = concat(message, "Alright!\n");
		}
		else if (nbWrongRequets == 8)
		{
		     message = concat(message, "[axe noise] AHAHAUGHH!\nSorry! Sorry, force of habit.\nWell, he is dead...\nLooks like I have won at Cards Against Humanity!\n");
		     nbWrongRequets = -1;
		}
	    }
	    else if (noWrongStory == 1)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, users[userNumber].username);
		     message = concat(message, ", I don't see your name on the list...\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "Oh God, no...\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, "Okay we're past our time limit, ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, "!\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "You're a bag of dicks\n");
		}
		else if (nbWrongRequets == 4)
		{
		     message = concat(message, "Oh my God, I don't care!\n");
		}
		else if (nbWrongRequets == 5)
		{
		     message = concat(message, "Listen ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, ", there must have been a mistake\nOn this show you've got to get right to the point of your game.\nLike the ship from Galaga\n\nHi, I shoot stuff in space\n\nAnd this car from Pole Position\n\nI'm a car!\n\nThat's great!\n");
		}
		else if (nbWrongRequets == 6)
		{
		     message = concat(message, "You know we've been through this before with your boy ");
		     for (int i = 0; i < numberOfUsers; i++)
		     {
			if (users[i].isDeconected == 1 && i != userNumber)
			{
			    message = concat(message, users[i].username);
			    break;
			}
		     }
		     message = concat(message, ".\nAnd he talked too long I contemplated ending my life.\nSo let's keep things nice and simple like the hero over there.\nFrom the Atari game Adventure.\n\nI'm literally just a yellow square!");
		}
		else if (nbWrongRequets == 7)
		{
		     message = concat(message, "I don't give a frog's fat ass.\n");
		}
		else if (nbWrongRequets == 8)
		{
		     message = concat(message, "Listen ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, " I've taken all I can take.\nJust because your game is simple doesn't mean that it's lame.\nTell them, kid from Paperboy\n\nYo, I deliver those papers!\n\nThe guy from Elevator Action\n\nUh, elevators?\n\nOkay!\n");
		}
		else if (nbWrongRequets == 9)
		{
		     message = concat(message, "Dear God.\nWhy can't I just have a single panel of guests\nWho can say their plots in forty fuckin' minutes or less\nNow just watch me, Snake before you make me reach for a gun\nI'll summarize your game and show you how this shit is really motherfuckin' done!\nHow it's motherfuckin' done!\n'You make card jokes and make your frends laugh. The End.'\n");
		}
		else if (nbWrongRequets == 10)
		{
		     message = concat(message, "My God, can I get a replacement guest with a simple plot please?\n\nHi, I'm Sora from Kingdom Hearts!\n\nNooooooooooo!\n");
		     nbWrongRequets = -1;
		}
	    }
	    else if (noWrongStory == 2)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, "Hello, ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, ".\nAnd Mrs. Game\nWelcome to couples' therapy.\nI'm Dr. Wily.\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "Not anymore.\nThose days are behind me.\nDon't question it!\nShut up.\nJust tell me the problem over theses wrongly written requests.\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, "It would be seeming to me that the problem here\nIs you don't listen to your game, it is being clear.\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "Quiet!\nThe doctor is talking -- there must be ORDER!\n...Sorry, I'm not evil anymore.\n");
		}
		else if (nbWrongRequets == 4)
		{
		     message = concat(message, "You must use numbers to send requests\nAnd then use them on your game when it is being used\nMaybe it likes new turns from number 11\nOr getting card numbers by number 13; it's a client's dream\n");
		}
		else if (nbWrongRequets == 5)
		{
		     message = concat(message, "Your playtrough will be healthy like pure springwater\nNow leave my office before you are SLAUGHTERED!\n");
		}
		else if (nbWrongRequets == 6)
		{
		     message = concat(message, "So ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, " harnessed all the powers of the requests\nAnd killed his brain tumer with his mega laser walktrough-blaster\nAnd then he played his game until it screamed 'Yes! More!'\nThen it was working again, 'cause your a DUMB RETARD\n");
		}
		else if (nbWrongRequets == 7)
		{
		     message = concat(message, "Sorry, that was exagerated.\nYou are dumb, though\n");
		}
		else if (nbWrongRequets == 8)
		{
		     message = concat(message, "Nothing!\n...Douche.\n");
		     nbWrongRequets = -1;
		}
	    }
	    else if (noWrongStory == 3)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, "Yo, fuck your mistakes, ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, ", it's time to get real!\nI wanna kill a motherfucker just to see how it feels!\nIf you dare to come at me, you better come at me strong!\nI'll break your sorry-ass legs if you look at me wrong!\nI'm Linux the server, you little bitch, and I'm on the attack!\nMy endocrine system is fucking riddled with crack!\nNow I've got hallucinations that are out of control!\nAnd I can taste colors, and I'm gonna skull fuck your soul!\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "Hey stand the fuck back, I've got a better solution!\nIt's time for old school, street justice death execution.\nClient-bitch, here's some motherfucking caps for your head!\nBlaow blaow, now that brain-thumeur-shaped cocksucker's dead!\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, "I'm Linux the server, do I have to fucking say it again?\nI am exploding with evil that you cannot comprehend\nI just committed a murder, but there is no time to rest\nLet's get our friends over, have a giant forest fuck fest\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "[gunshots]\n");
		     nbWrongRequets = -1;
		}
	    }
	    else if (noWrongStory == 4)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, "There was a server in the depths of space\nAnd it could easily combine your stupid requests with your game.\nIts name was Linux, and it would destroy  problems.\nWhen it wasn't totally pissed, it was extremely annoyed\nIt stood up to every challenge, no matter however demanding.\nAnd its access was amazing, and its prices were outstanding.\n\nWHAT?!\n\nUh, nothing!\nI was just saying that you're usefull\nUh... okay... hey, look over there! It's a dumb client!\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "Is that a problem, you FUCK?!\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, users[userNumber].username);
		     message = concat(message, " was hesitating, but Linux was set to fight\nIt got into a processing stance that made its code look super-tight\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "What pisses me off most in this world\nIs when clients get dumb when they all find out I'm a how I work\nSo do me a favor, and take your comands and your files\nAnd shove them so far up your ass that they end up behind your eyes!\nStop treating me like I'm simple\nWindows's a operating system, but it gets respect!\n");

		}
		else if (nbWrongRequets == 4)
		{
		     message = concat(message, "Get the fuck off my server, this is your last chance!\n");
		}
		else if (nbWrongRequets == 5)
		{
		     message = concat(message, "That's it, you're all fucking dead!\n");
		}
		else if (nbWrongRequets == 6)
		{
		     message = concat(message, "[explosion sounds]\nWhoops.\nKilled the program.\n");
		     nbWrongRequets = -1;
		}
	    }
	    else if (noWrongStory == 5)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, "Hey ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, "!\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "You know I think you're a fucking dick right?\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, "Well, I think we should settle this shit once and for all with a rap battle to the death\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "Do you think you can stop eating penis long enough to do that?\n");
		}
		else if (nbWrongRequets == 4)
		{
		     message = concat(message, "Alright, let's do this!!\n");
		}
		else if (nbWrongRequets == 5)
		{
		     message = concat(message, "Round 1! Rap!\n\nFuck you, ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, ", you're such a little fucking bitch.\nI'm gonna break your fucking spine in half and throw you in a ditch.\nStart up the fucking beat and drop the motherfucking bass.\nSo I can shoot a load of requests all over your face.\nI'll break your glass jaw like it was made of fucking straw, man.\nShredding you up worse than Vega fapping with his claw hand.\n Cammy and Chun-Li don't think you're sexy at all.\nThey're both coming home with me, one for each of my balls\nLike the bonus round car your ass is getting destroyed.\nMy cock is more swollen than Zangief's thyroid.\nYour dick's three inches hard, I'm working with a soft ten.\nSo what you got to motherfucking say to me, ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, "?\n");
		}
		else if (nbWrongRequets == 6)
		{
		     message = concat(message, "Round 2! Rap!\n\nIt's my honest suspicion\nYou're gonna want a physician\nOnly morticians are the one to help your future condition\nCause me whooping on your ass is a time honored tradition.\nSo now I'll do it even faster in the Turbo edition!\nWatch your back, bitch, I'm gonna make you scream.\nMy dick shoots farther than the arm of Dhalsim.\nJust like Sagat's chest, you're gonna need a skin graft.\nNow, please enjoy the tart, tangy taste of my shaft.\nMy rhymes are fat like the sumo E. Honda.\nI'm the king of dick jungle with my giant anaconda\nHarness my Chi to beat your ass with a Dao.\nSo what you got to motherfucking say to me now?\n");
		}
		else if (nbWrongRequets == 7)
		{
		     message = concat(message, "Hadouken!\n");
		}
		else if (nbWrongRequets == 8)
		{
		     message = concat(message, "Hey, you did it!\nYou rhymed on beat!\n");
		}
		else if (nbWrongRequets == 8)
		{
		     message = concat(message, "Yeah, great job, man!\nI knew you could do it.\n");
		}
		else if (nbWrongRequets == 9)
		{
		     message = concat(message, "Tatsumaki Senpukyaku!\n");
		     nbWrongRequets = -1;
		}
	    }
	    else if (noWrongStory == 6)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, "Hold on a minute ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, "!\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "I see that you're embarkin' on another epic game.\nYou're gonna use your cards to make your friends laugh\nBut you'll need a magic weapon that'll never ever miss.\nIt's dangerous to go alone, take this!\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, "Yes, I can't lie, I have painted my schween.\nNow grab your destiny if you know what I mean.\nWait a minute ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, ", don't leave the cave, where do you think you're going?\nThis is a great chance to fondle a scrotum that you're blowing\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "Hold on a minute ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, "!\n");
		}
		else if (nbWrongRequets == 4)
		{
		     message = concat(message, "This is a place you can't survive with just your sword and your wits.\nIt's dangerous to go alone, take this!\n");
		}
		else if (nbWrongRequets == 5)
		{
		     message = concat(message, "Don't be that way bitch let me introduce you\nTo my three best friends Mr. Johnson and the Juice Crew.\nIf you see the Princess Zelda, well you know you're gonna grab her\nSo why don't you try to come grab my inflatable poo jabber.\n");
		}
		else if (nbWrongRequets == 6)
		{
		     message = concat(message, "Hold on a minute ");
		     message = concat(message, users[userNumber].username);
		     message = concat(message, "!\n");
		}
		else if (nbWrongRequets == 7)
		{
		     message = concat(message, "You're in Raccoon City, it's a zombie abyss!\nIt's dangerous to go alone, take this!\n");
		}
		else if (nbWrongRequets == 8)
		{
		     message = concat(message, "So is that a 'No' on the handjob or...? Okay\n");
		     nbWrongRequets = -1;
		}
	    }
	    else if (noWrongStory == 7)
	    {
		if (nbWrongRequets == 0)
		{
		     message = concat(message, "That sounds nice, how do we do it?\n");
		}
		else if (nbWrongRequets == 1)
		{
		     message = concat(message, "I don't think I wanna do that.\n");
		}
		else if (nbWrongRequets == 2)
		{
		     message = concat(message, "Wait, no.\n");
		}
		else if (nbWrongRequets == 3)
		{
		     message = concat(message, "That's not cool.\n");
		}
		else if (nbWrongRequets == 4)
		{
		     message = concat(message, "Can't we all just get along?\n");
		}
		else if (nbWrongRequets == 5)
		{
		     message = concat(message, "Is the time almost over?\nI can't tell, my face is mashed.\n");
		}
		else if (nbWrongRequets == 6)
		{
		     message = concat(message, "This blows.\n");
		}
		else if (nbWrongRequets == 7)
		{
		     message = concat(message, "That is the last goddamn straw...\n");
		}
		else if (nbWrongRequets == 8)
		{
		     message = concat(message, "Hey look at me now!\nI'm beating up friends.\nI have no regrets, this is the fucking best!\nYes I can see now.\nWe're having fun in the end!\nNow it all makes sense\n");
		     nbWrongRequets = -1;
		}
	    }
	    nbWrongRequets++;
	}
	message = concat(message, "\n\0");
	//message = concat(message, "\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\33[2K\0");
	write(users[userNumber].socket, message , strlen(message));
	puts(message);
	char str[15];
	sprintf(str, "%zu", strlen(message));
	puts(str);
	for (int i = strlen(message); i >= 0; i--)
	{
	    message[i] = '\0';
	}
	for (int i = strlen(client_message); i >= 0; i--)
	{
	    client_message[i] = '\0';
	}
	puts(message);
	puts(client_message);
	pthread_mutex_unlock(&lock);//debarrer le mutex pour liberrer les variables
    }
    //Free the socket pointer
    free(socket_desc);
    close(users[userNumber].socket);
    users[userNumber].isDeconected = 1;
    pthread_mutex_unlock(&lock);//debarrer le mutex pour liberrer les variables
    puts("Bye!");
    return 0;
}


